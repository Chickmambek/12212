# This file is no longer needed as we switched to Django Q
# You can safely delete it.

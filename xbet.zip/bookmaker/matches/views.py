# matches/views.py
import requests
from django.http import JsonResponse
from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
from .models import Match, Odds, Bookmaker, Team, Bet, ExpressBet, ExpressBetSelection
from accounts.models import Profile
from django.db.models import Prefetch, Sum, Q
from accounts.services.telegram_notifier import notify_site_visit
from django.contrib.auth.decorators import login_required
from django.contrib import messages
import json
from decimal import Decimal, InvalidOperation
from django.db import transaction, OperationalError

API_KEY = "973fb2112f51a596e7c5f0138fecce97"  # Change this


def matches_dashboard(request):
    # Notify Telegram about the visit
    notify_site_visit(request)

    # Search functionality
    search_query = request.GET.get('q', '')
    
    # Base querysets
    live_qs = Match.objects.filter(status=Match.STATUS_LIVE)
    upcoming_qs = Match.objects.filter(
        match_date__gte=timezone.now(),
        match_date__lte=timezone.now() + timezone.timedelta(days=7),
        status=Match.STATUS_UPCOMING
    )
    today_qs = Match.objects.filter(
        match_date__date=timezone.now().date(),
        status=Match.STATUS_UPCOMING
    )
    finished_qs = Match.objects.filter(status=Match.STATUS_FINISHED)

    # Apply search filter if query exists
    if search_query:
        search_filter = Q(home_team__name__icontains=search_query) | \
                        Q(away_team__name__icontains=search_query) | \
                        Q(league__icontains=search_query)
        
        live_qs = live_qs.filter(search_filter)
        upcoming_qs = upcoming_qs.filter(search_filter)
        today_qs = today_qs.filter(search_filter)
        finished_qs = finished_qs.filter(search_filter)

    # Filter out matches with no odds for non-admin users
    if not request.user.is_staff:
        live_qs = live_qs.filter(odds__isnull=False).distinct()
        upcoming_qs = upcoming_qs.filter(odds__isnull=False).distinct()
        today_qs = today_qs.filter(odds__isnull=False).distinct()
        # Finished matches can be shown even without odds as they are historical

    # Prefetch related data
    prefetch_odds = Prefetch('odds', queryset=Odds.objects.select_related('bookmaker'))
    
    live_matches = live_qs.select_related('home_team', 'away_team').prefetch_related(prefetch_odds).order_by('match_date')
    upcoming_matches = upcoming_qs.select_related('home_team', 'away_team').prefetch_related(prefetch_odds).order_by('match_date')
    today_matches = today_qs.select_related('home_team', 'away_team').prefetch_related(prefetch_odds)
    finished_matches = finished_qs.select_related('home_team', 'away_team').order_by('-match_date')[:20]

    # Get all bookmakers
    bookmakers = Bookmaker.objects.all()

    context = {
        'live_matches': live_matches,
        'upcoming_matches': upcoming_matches,
        'today_matches': today_matches,
        'finished_matches': finished_matches,
        'bookmakers': bookmakers,
        'current_time': timezone.now(),
        'search_query': search_query,
    }
    return render(request, 'dashboard.html', context)


def match_detail(request, match_id):
    """Detailed view for a specific match"""
    match = get_object_or_404(Match.objects.select_related('home_team', 'away_team').prefetch_related(
        Prefetch('odds', queryset=Odds.objects.select_related('bookmaker'))
    ), id=match_id)

    # Check if odds exist for non-admin users
    if not request.user.is_staff and not match.odds.exists():
        messages.warning(request, "This match is currently unavailable for betting.")
        return redirect('dashboard')

    # Handle AJAX request for live updates
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        odds = match.odds.first()
        data = {
            'status': match.status,
            'home_score': match.home_score,
            'away_score': match.away_score,
            'odds': {
                'home': odds.home_odds if odds else None,
                'draw': odds.draw_odds if odds else None,
                'away': odds.away_odds if odds else None,
                '1x': match.odds_1x,
                '12': match.odds_12,
                'x2': match.odds_x2,
                'over_25': match.odds_over_2_5,
                'under_25': match.odds_under_2_5,
                'handicap_home': match.odds_handicap_home,
                'handicap_away': match.odds_handicap_away,
                'btts_yes': match.odds_btts_yes,
                'btts_no': match.odds_btts_no,
            }
        }
        return JsonResponse(data)

    # Get user's bets for this match if logged in
    user_bets = []
    if request.user.is_authenticated:
        user_bets = Bet.objects.filter(user=request.user, match=match).order_by('-created_at')

    context = {
        'match': match,
        'user_bets': user_bets,
    }
    return render(request, 'match_detail.html', context)


def teams_list(request):
    """View to display all teams with logos"""
    teams = Team.objects.all().order_by('name')

    context = {
        'teams': teams,
    }
    return render(request, 'matches/teams.html', context)

@login_required
def place_bet(request, match_id):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=405)

    match = get_object_or_404(Match, id=match_id)

    # Check if match is finished (Block betting)
    if match.status == Match.STATUS_FINISHED:
        return JsonResponse({'error': 'This match has finished!'}, status=400)
        
    # Check if match has started but is NOT live (Block betting)
    # Allow betting on live matches
    if match.status != Match.STATUS_LIVE and match.match_date < timezone.now():
        return JsonResponse({'error': 'This match has already started!'}, status=400)

    # Handle both JSON and Form data
    try:
        if request.content_type == 'application/json':
            data = json.loads(request.body)
            bet_type = data.get('bet_type')
            amount_str = data.get('amount')
            odds_value_str = data.get('odds')
        else:
            bet_type = request.POST.get('bet_type')
            amount_str = request.POST.get('amount')
            odds_value_str = request.POST.get('odds')
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)

    try:
        amount = Decimal(str(amount_str))
        odds_value = Decimal(str(odds_value_str))
    except (ValueError, TypeError):
        return JsonResponse({'error': 'Invalid bet amount or odds.'}, status=400)

    if amount <= 0:
        return JsonResponse({'error': 'Bet amount must be positive.'}, status=400)

    # Atomic transaction to ensure balance is deducted only if bet is created
    try:
        with transaction.atomic():
            # Re-fetch profile to lock it for update
            profile = Profile.objects.select_for_update().get(user=request.user)

            if profile.balance < amount:
                return JsonResponse({'error': 'Insufficient balance!'}, status=400)

            # Deduct balance
            profile.balance -= amount
            profile.save()

            # Create Bet
            potential_payout = amount * odds_value
            bet = Bet.objects.create(
                user=request.user,
                match=match,
                bet_type=bet_type,
                odds=odds_value,
                amount=amount,
                potential_payout=potential_payout
            )
            
            return JsonResponse({
                'success': True,
                'message': f'Bet placed successfully! Potential payout: {potential_payout}',
                'new_balance': float(profile.balance),
                'bet_id': bet.id
            })

    except Exception as e:
        return JsonResponse({'error': f'An error occurred: {str(e)}'}, status=500)


def clean_decimal(value, default="0.0"):
    """Helper to prevent decimal.InvalidOperation by stripping non-numeric chars."""
    if value is None:
        return Decimal(default)
    # Strip everything except digits and the decimal point
    sanitized = "".join(c for c in str(value) if c.isdigit() or c == '.')
    try:
        return Decimal(sanitized) if sanitized else Decimal(default)
    except InvalidOperation:
        return Decimal(default)


@login_required
def place_express_bet(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request method'}, status=405)

    # 1. Parse and Sanitize Input
    try:
        data = json.loads(request.body)
        bets_data = data.get('bets') or data.get('selections', [])
        stake = clean_decimal(data.get('stake'))
    except (json.JSONDecodeError, ValueError, TypeError):
        return JsonResponse({'error': 'Invalid data format'}, status=400)

    if stake <= 0:
        return JsonResponse({'error': 'Stake must be positive'}, status=400)
    if not bets_data:
        return JsonResponse({'error': 'No selections provided'}, status=400)

    # 2. Execution with Retry Logic for SQLite Locks
    max_retries = 5
    retry_delay = 0.5  # half a second

    for attempt in range(max_retries):
        try:
            with transaction.atomic():
                # select_for_update() locks the user row to prevent double-spending
                profile = Profile.objects.select_for_update().get(user=request.user)

                if profile.balance < stake:
                    return JsonResponse({'error': 'Insufficient balance'}, status=400)

                total_odds = Decimal('1.0')
                selections = []

                # Validate all matches before doing any work
                for bet_item in bets_data:
                    match_id = bet_item.get('match_id')
                    bet_type = bet_item.get('selection') or bet_item.get('type')
                    odds_val = clean_decimal(bet_item.get('odds'))

                    match = Match.objects.get(id=match_id)

                    # Validation Logic
                    if match.status == 'finished':
                        raise ValueError(f"Match {match.home_team} vs {match.away_team} has already finished.")

                    # Check if match started (only for non-live matches)
                    if match.status != 'live' and match.match_date < timezone.now():
                        raise ValueError(f"Match {match.home_team} has already started.")

                    total_odds *= odds_val
                    selections.append({
                        'match': match,
                        'bet_type': bet_type,
                        'odds': odds_val
                    })

                # Deduct Balance
                profile.balance -= stake
                profile.save()

                # 3. Create Bet Records
                if len(selections) == 1:
                    sel = selections[0]
                    potential_payout = stake * sel['odds']
                    bet = Bet.objects.create(
                        user=request.user,
                        match=sel['match'],
                        bet_type=sel['bet_type'],
                        odds=sel['odds'],
                        amount=stake,
                        potential_payout=potential_payout
                    )
                else:
                    potential_payout = stake * total_odds
                    express_bet = ExpressBet.objects.create(
                        user=request.user,
                        amount=stake,
                        total_odds=total_odds,
                        potential_payout=potential_payout
                    )
                    for sel in selections:
                        ExpressBetSelection.objects.create(
                            express_bet=express_bet,
                            match=sel['match'],
                            bet_type=sel['bet_type'],
                            odds=sel['odds']
                        )

                return JsonResponse({
                    'success': True,
                    'message': 'Bet placed successfully!',
                    'new_balance': float(profile.balance)
                })

        except OperationalError as e:
            # If the DB is locked by the scraper, wait and try again
            if "locked" in str(e).lower() and attempt < max_retries - 1:
                time.sleep(retry_delay)
                continue
            return JsonResponse({'error': 'Database busy. Please try again in 1 second.'}, status=503)

        except Match.DoesNotExist:
            return JsonResponse({'error': 'One or more matches no longer exist.'}, status=404)
        except ValueError as e:
            return JsonResponse({'error': str(e)}, status=400)
        except Exception as e:
            return JsonResponse({'error': f'Internal Server Error: {str(e)}'}, status=500)


@login_required
def my_bets(request):
    # Get all single bets for the current user
    single_bets = Bet.objects.filter(user=request.user).select_related(
        'match__home_team', 'match__away_team'
    ).order_by('-created_at')

    # Statistics for single bets
    total_single = single_bets.count()
    won_single = single_bets.filter(status='won').count()
    pending_single = single_bets.filter(status='pending').count()
    lost_single = single_bets.filter(status='lost').count()

    # Total stake for single bets
    total_stake_single = single_bets.aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
    # Total payout for won single bets
    won_payout_single = single_bets.filter(status='won').aggregate(Sum('potential_payout'))['potential_payout__sum'] or Decimal('0')

    # Get express bets
    express_bets = ExpressBet.objects.filter(user=request.user).prefetch_related(
        'selections__match__home_team', 'selections__match__away_team'
    ).order_by('-created_at')

    total_express = express_bets.count()
    won_express = express_bets.filter(status='won').count()
    pending_express = express_bets.filter(status='pending').count()
    lost_express = express_bets.filter(status='lost').count()

    total_stake_express = express_bets.aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
    won_payout_express = express_bets.filter(status='won').aggregate(Sum('potential_payout'))['potential_payout__sum'] or Decimal('0')

    # Combine stats
    total_bets = total_single + total_express
    won_bets = won_single + won_express
    pending_bets = pending_single + pending_express
    total_stake = total_stake_single + total_stake_express
    total_won_payout = won_payout_single + won_payout_express

    # Net profit = total won payout - total stake (since payout includes stake)
    net_profit = total_won_payout - total_stake

    context = {
        'bets': single_bets,  # for single bets table (as before)
        'express_bets': express_bets,  # new for express bets
        'total_bets': total_bets,
        'won_bets': won_bets,
        'pending_bets': pending_bets,
        'net_profit': net_profit,
    }
    return render(request, 'matches/my_bets.html', context)
